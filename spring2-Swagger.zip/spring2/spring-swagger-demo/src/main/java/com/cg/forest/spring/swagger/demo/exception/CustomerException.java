package com.cg.forest.spring.swagger.demo.exception;

public class CustomerException extends RuntimeException {
	
	public CustomerException(String msg)
	{
		super(msg);
	}

}
