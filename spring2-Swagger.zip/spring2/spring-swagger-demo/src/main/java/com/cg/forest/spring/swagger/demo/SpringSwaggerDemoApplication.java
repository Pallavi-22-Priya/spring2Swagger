package com.cg.forest.spring.swagger.demo;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.cg.forest.spring.swagger.demo.dto.Customer;
import com.cg.forest.spring.swagger.demo.service.CustomerService;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.forest.spring.swagger.demo")
@EnableCaching
public class SpringSwaggerDemoApplication {
	//@Autowired
	//private CustomerService customerService;

	public static void main(String[] args) {
		SpringApplication.run(SpringSwaggerDemoApplication.class, args);
	}
	/*@Bean
	InitializingBean sendDatabase()
	{
		return ()->{
			customerService.serviceaddCustomer(new Customer("Pallavi","pallu@gmail.com","Daddy@09","dfghjhk","nellore","123456","1234567890"));
			
		};
		
	}*/

}
