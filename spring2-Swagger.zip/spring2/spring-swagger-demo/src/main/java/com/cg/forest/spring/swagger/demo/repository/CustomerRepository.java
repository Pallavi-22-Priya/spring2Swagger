package com.cg.forest.spring.swagger.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.forest.spring.swagger.demo.dto.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer> {
	
		
	
}
